
var name1 = "Hung";
var age1 = 36;
var sayHello1 = function(){
    console.log(` Lab 1 bài 1 \n
        I'm ${name1}. I'm ${age1}.`)
}
var name2 = "Nam";
var age2 =27;
var sayHello2 = function(){
    console.log(` I'm ${name2}. I'm ${age2}. \n
                ==========================
            `)
}
sayHello1();
sayHello2();