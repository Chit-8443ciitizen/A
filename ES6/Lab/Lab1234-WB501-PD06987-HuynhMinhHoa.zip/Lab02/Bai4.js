// =============================bai 4 ======================================= //
console.log(`Lab 2 bài 4 \n`)
function spreadOut(){
    let fragment = ['to','code'];
    let fragmentFirst = [ 'learning' ];
    let fragmentLast = [ 'is', 'fun'];
    let sentence =[
        ...fragmentFirst, ...fragment, ...fragmentLast
    ];
    // trả lời
    
    
    return sentence; 
    
}
console.log(spreadOut());
// const bai4 = spreadOut();
// document.getElementsById("bai4").innerHTML= bai4;
console.log(`=================== \n`)