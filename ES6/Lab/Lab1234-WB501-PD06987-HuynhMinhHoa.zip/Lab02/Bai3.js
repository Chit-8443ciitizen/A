// =============================bai 3 ======================================= //
console.log(`Lab 2 bài 3 \n`)
const arr1 = ['JAN', 'FEB', 'MAR', 'APR', 'MAY'];   
let arr2;

arr2 = [];
// trả lời
arr2 = [...arr1];     
console.log(arr2); 
