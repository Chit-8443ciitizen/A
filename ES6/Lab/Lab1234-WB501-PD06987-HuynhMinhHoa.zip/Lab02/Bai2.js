
const source = [1,2,3,4,5,6,7,8,9,10];
function removeFirstTwo(list){
    // const list = source;
    const [first, second, arr] = source;
    // trả lời
    // arr array = 
    return arr;
}

const arr = removeFirstTwo(source);
document.getElementsByClassName("bai2")[0].innerHTML= arr;
document.getElementsByClassName("bai2")[1].innerHTML= source;
